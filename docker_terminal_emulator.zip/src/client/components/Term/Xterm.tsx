import * as React from 'react';
import { Terminal, ITerminalOptions } from 'xterm';
import { FitAddon } from "xterm-addon-fit";
import { WSConnection } from "../../lib/WSConnection";
import { Logger } from '../../../common/Logger';

const console = new Logger(__filename);

const { useEffect, useState } = React;

interface Props {
	connectionName?: string
}

const xtermOptions: ITerminalOptions = {
	rendererType: 'dom',
	convertEol: true,
	rightClickSelectsWord: true,
	theme: {
		foreground: 'green'
	}
}

const fitAddon = new FitAddon();

const initXterm = (connection: WSConnection, target: HTMLElement, setPid: (pid: number) => void) => {
	const xterm = new Terminal(xtermOptions);
	xterm.open(target);
	connection.on('processData', (data) => {
		xterm.write(data);
	});
	connection.on('error', (data) => {
		xterm.write(data);
	});
	connection.on('pid', (pid) => {
		xterm.clear();
		setPid(parseInt(pid));
	});
	connection.on('connected', (pid) => {
		if (connection.name) {
			setPid(parseInt(connection.name));
			connection.send('clear\n');
		}
	});
	xterm.onData(data => {
		console.log('---> onData', data);
		connection.send(data);
	});
	xterm.loadAddon(fitAddon);
	fitAddon.fit();
	console.log("log: initXterm -> xterm", xterm.cols);
}

export const Xterm: React.FunctionComponent<Props> = ({ connectionName = '' }) => {
	const ref = React.createRef<HTMLDivElement>();
	const [pid, setPid] = useState(0);
	const [connection] = useState(() => {
		return new WSConnection(connectionName)
	});

	// Execute only once, when component is ready
	useEffect(() => {
		console.log("log: connection", connection);
		initXterm(connection, ref.current, setPid);
	}, []);

	return <div className="term">
		<div>{pid}</div>
		<div ref={ref}></div>
	</div>
}
