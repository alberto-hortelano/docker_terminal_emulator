import * as React from 'react';
import { Logger } from '../../../common/Logger';
import { Xterm } from '../Term/Xterm';

const console = new Logger(__filename);

const { useEffect, useState } = React;


const getPtys = async (cb: (value: string[]) => void) => {
	const res = await fetch('/ptys');
	console.log("log: getPtys -> res", res);
	const ptys: string[] = await res.json();
	console.log("log: getPtys -> ptys", ptys);
	cb(ptys);
}

export const Connection: React.FunctionComponent = ({ children }) => {
	const [ptys, setPtys] = useState<string[]>([]);
	const ref = React.createRef<HTMLButtonElement>();
	// Execute only once, when component is ready
	useEffect(() => {
		getPtys(setPtys);
		ref.current.addEventListener('click', () => {
			ptys.push('');
			console.log("log: Connection:React.FunctionComponent -> ptys", ptys);
			setPtys(ptys);
			console.log("log: Connection:React.FunctionComponent -> ptys 2", ptys);
		});
	}, []);

	return <div id="Connection">
		<button ref={ref}>New Terminal</button>
		{
			ptys.map((ptyName, i) => {
				console.log('Xterm', i, ptyName)
				console.log("log: Connection:React.FunctionComponent -> ptys 3", ptys);
				return <Xterm key={i} connectionName={ptyName}></Xterm>
			})
		}
	</div>
}