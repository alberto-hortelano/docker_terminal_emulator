export const paths = {
	ws: '/ws', // websockets path
}