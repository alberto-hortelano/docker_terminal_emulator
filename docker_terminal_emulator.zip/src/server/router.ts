import { Router } from 'express';
import { getPtys } from './wss';

export const router = Router();

router.get('/ptys', (req, res) => {
	const ptys = getPtys();
	console.warn("log: ptys", ptys);
	res.send(ptys);
});

router.put('/a', (req, res) => {
	res.send('aaaaa')
});

router.get('/', (req, res) => {
	res.send('root')
});
