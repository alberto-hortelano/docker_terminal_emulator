// import { readdir } from "../../lib/promisified";

// export const projects = new Api({
// 	path: 'projects',
// 	actions: {
// 		'list': async (req, res) => {
// 			res.send(await readdir('/'))
// 		}
// 	}
// });