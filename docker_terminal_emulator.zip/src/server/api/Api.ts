class Api {
	constructor(parameters) {

	}
}
