import * as WS from "ws";
import { Server as HttpServer } from "http";
import { spawn, IPty } from "node-pty";
import { exec } from "child_process";
import { parse } from "url";
import { Logger } from "../common/Logger";
import { encodeData } from "../common/lib";

const console = new Logger();

const ptys: { [pid: number]: IPty } = {};

const getChildIds = (parentId: number) => new Promise<string>((resolve, reject) => {
	exec(`pgrep -P ${parentId}`, (error, stdout) => {
		console.log("log: getChildId -> stdout", stdout);
		if (!error) {
			const childIds = stdout.split('\n').map(s => parseInt(s)).filter(n => !isNaN(n));
			console.log("log: getChildId -> childIds", childIds);
			resolve(childIds.join(' '));
		} else if (error.code === 1) { // No child processes
			resolve();
		} else { // Error
			reject(error);
		}
	});
});

let killChildProcesses = async (event: string, exitStatus?: number | Error) => {
	console.warn("######## log: exit      ", event, exitStatus);
	killChildProcesses = () => console.log("######## log: exit", event, exitStatus); // Only called once
	process.stdin.resume();
	try {
		const childIds = await getChildIds(process.pid);
		if (childIds) {
			console.log('log: killChildProcesses', childIds);
			exec(`kill ${childIds}`);
		}
	} catch (error) {
		console.log("log: killChildProcesses -> error", error);
		// } finally {
		// 	process.exit();
	}
};

//do something when app is closing
process.on('exit', (exitCode) => { killChildProcesses('exit', exitCode) });

//catches ctrl+c event
process.on('SIGINT', (signal) => { killChildProcesses(signal) });

// catches "kill pid" (for example: nodemon restart)
process.on('SIGUSR1', (signal) => { killChildProcesses(signal) });
process.on('SIGUSR2', (signal) => { killChildProcesses(signal) });

//catches uncaught exceptions
process.on('uncaughtException', (error) => { killChildProcesses('uncaughtException', error) });


const initPty = (ws: WS) => {
	const ptyProcess = spawn('sh', [], {
		name: 'xterm-256color',
		cols: 80,
		rows: 30,
		useConpty: true,
		cwd: './',
		env: process.env,
	});
	ptys[ptyProcess.pid] = ptyProcess;
	console.log("log: initPty -> ptyProcess", ptyProcess);
	ws.send(encodeData('pid', ptyProcess.pid.toString()));
	return ptyProcess;
}

const linkConnectionToPty = (ws: WS, pty: IPty) => {
	// WS
	ws.on('message', message => {
		console.log("log: initWebSocket    -> message", message);
		try {
			pty.write(message.toString());
		} catch (error) {
			console.error("log: initWebSocket -> error", error);
			pty.write(error.message);
		}
	});
	// ws.on('close', (code, reason) => {
	// 	console.log('ws.close', { pid: pty.pid, code, reason});
	// });
	ws.on('error', err => {
		console.error('ws.close -> error', err, pty.pid);
		pty.kill();
	});
	// PTY
	pty.onData(data => {
		console.log("log: ptyProcess -> data", pty.pid, data);
		ws.send(encodeData('processData', data));
	});
}

export const getPtys = () => JSON.stringify(Object.keys(ptys));

export const initWebSocket = (server: HttpServer, path: string) => {
	const wss = new WS.Server({ server, path });
	console.log("log: initWebSocket -> wss", wss);
	wss.on('connection', async (ws, req) => {
		const name = parse(req.url, true)?.query?.name?.toString();
		console.log("log: initWebSocket -> name", name, ptys[name], ptys);
		const pty = ptys[name] || initPty(ws);
		linkConnectionToPty(ws, pty);
		console.warn("log: initWebSocket ->", pty.pid);
	});
};
