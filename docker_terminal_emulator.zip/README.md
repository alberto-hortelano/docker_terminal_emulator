# Docker terminal emulator Features
* Virtual consoles to run services
* Open console in any container, any folder
* Store configuration to open several consoles with one click
# Notes:
* **Chrome DevTools** open console and click esc 2 times, the node logo appears as usual

# Logica:
* Proyectos: Lista de proyectos para elegir
* Proyecto: Una carpeta que contiene todo lo necesario para desarrollar un proyectos
	- descripcion: texto
	- comandos: tarjeta con nombre comando y descripcion y un boton para ejecutar
	- scripts: lista de comando
	
# Connections:
 1. Send term id from client
 1. Find term by id
	1. Send connection to term
	1. Create new term
